<?php
/**
 * Created by RedChamps.
 * User: Rav
 * Date: 29/10/18
 * Time: 3:34 PM
 */
namespace RedChamps\ShareCart\Block\Order\Email;

use Magento\Sales\Block\Order\Email\Items as CoreOrderItems;

class Items extends CoreOrderItems
{

}
